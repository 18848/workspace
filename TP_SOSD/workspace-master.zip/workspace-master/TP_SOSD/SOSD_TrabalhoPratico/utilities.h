#ifndef UTILITIES_H_
#define UTILITIES_H_

    int itostring(long int num, char** destiny);
    int strcmp(const char* first, const char* sec);
    int strsize(const char* string);

#endif