#ifndef FICHEIRO_H_
#define FICHEIRO_H_

    int mostra(char* nome);
    int conta(char* nome);
    int apaga(char* nome);

#endif