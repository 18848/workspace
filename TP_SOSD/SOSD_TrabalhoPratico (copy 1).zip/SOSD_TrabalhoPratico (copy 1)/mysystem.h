#ifndef MYSYSTEM_H_
#define MYSYSTEM_H_

    int mysystem(char* cmd, char* const* args);
    int command_construct(char** cmd);

#endif